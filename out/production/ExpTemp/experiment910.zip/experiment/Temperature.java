package experiment;

public class Temperature {

    protected String theMonth(String[] month, int x) {
        if (x <= month.length && x > 0) {
            return month[--x];
        } else {
            return "wrong number - sorry!";
        }
    }

    protected double celsiusDegeree(double[] celsius, int y) {
        if (y <= celsius.length && y > 0) {
            return celsius[--y];
        } else {
            return 0;
        }
    }

    protected double kelvinDegeree(double[] kelvin, int k) {
        if (k <= kelvin.length && k > 0) {
            return kelvin[--k];
        } else {
            return 0;
        }
    }

    protected double fahrenheitDegeree(double[] fahrenheit, int t) {
        if (t <= fahrenheit.length && t > 0) {
            return fahrenheit[--t];
        } else {
            return 0;
        }
    }
}