package experiment;

import java.util.Scanner;

public class MethodP {
    public static void main(String[] args) {

        String[] month = {"January","February","March","April","May","June","July","August","September","Oktober","November","December"};

        Temperature pickAmonth = new Temperature();

        double[] celsius = {-4.2, -0.5, 7.8, 9.4, 16.4, 21.3, 22.4, 23.7, 18.6, 10.8, 5.5, 3.3};

        double[] kelvin = new double[12];
        for (int i = 0; i < celsius.length; i++) {
            kelvin[i] = celsius[i] + 273.15;
        }

        double[] fahrenheit = new double[12];
        for (int i = 0; i < celsius.length; i++) {
            fahrenheit[i] = (celsius[i] * (9 / 5)) + 32;
        }

        Temperature celciusD = new Temperature();
        Temperature kelvinD = new Temperature();
        Temperature fahrenheitD = new Temperature();

        String aMonth = pickAmonth.theMonth(month, 3);
        double theCelsius = celciusD.celsiusDegeree(celsius, 3);
        double theKelvin = kelvinD.kelvinDegeree(kelvin, 3);
        double theFahrenheit = fahrenheitD.fahrenheitDegeree(fahrenheit, 3);

        System.out.println("You choosed the month: " + aMonth + " - the temperature in Celsius degrees: " + theCelsius + "; the temperature in Kelvin: " + theKelvin + "; and the temperature in fahrenheit: " + theFahrenheit);



    }

}
